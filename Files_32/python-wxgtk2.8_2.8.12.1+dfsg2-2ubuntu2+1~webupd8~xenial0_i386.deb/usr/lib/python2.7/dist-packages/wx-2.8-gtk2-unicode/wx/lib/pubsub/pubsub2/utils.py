'''
There are no utilities supported for legacy v2 of pubsub.


:copyright: Copyright 2006-2009 by Oliver Schoenborn, all rights reserved.
:license: BSD, see LICENSE.txt for details.

'''