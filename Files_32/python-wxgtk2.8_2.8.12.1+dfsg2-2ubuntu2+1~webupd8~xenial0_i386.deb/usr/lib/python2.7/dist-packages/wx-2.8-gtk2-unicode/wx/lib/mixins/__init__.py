#----------------------------------------------------------------------
# Name:        wxPython.lib.mixins
# Purpose:     A package for helpful wxPython mix-in classes
#
# Author:      Robin Dunn
#
# Created:     15-May-2001
# RCS-ID:      $Id: __init__.py 24889 2003-12-17 00:34:40Z RD $
# Copyright:   (c) 2001 by Total Control Software
# Licence:     wxWindows license
#----------------------------------------------------------------------
# 12/14/2003 - Jeff Grimmett (grimmtooth@softhome.net)
#
# o 2.5 compatability update.
#



